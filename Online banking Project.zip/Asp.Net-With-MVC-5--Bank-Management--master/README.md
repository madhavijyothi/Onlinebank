#### This is online banking project,users of this system are Customer,Officer,Loan Officer,Managing Director(MD),Manager.By using this project each banking related work can be done by this system.This system is done by me and my two teammate.We also use bootstrap in this project.
#### Language : JavaScript,CSS,C#
#### Framework : MVC-5
#### Key points:
###### 1. MD can see daily,annual,half year normal transaction and also loan related all issues.
###### 2. Manager is in charged of a branch,he can maintain every transaction using system.
###### 3. Customer can create account (Savings,Fixed Deposit,Loan) by officer and can take loan and pay loan using this system.
###### 4. This system also create repots like half year,Annual,daily transaction report branch wise and as a whole.
